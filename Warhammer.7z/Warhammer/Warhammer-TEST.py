from tkinter import *
from tkinter import messagebox


top = Tk()

C = Canvas(top, bg="blue", height=250, width=300)

#Background
background = PhotoImage(file = r"C:\Users\z003u1uy\Desktop\Python\Warhammer\Boards.png")
background_label = Label(top, image=background)
background_label.place(x=1, y=1, relwidth=1, relheight=1)

#Hero
hero1 = PhotoImage(file = r"C:\Users\z003u1uy\Desktop\Python\Warhammer\aaa.png")
hero1_label = Label(top, image=hero1)
hero1_label.place(x=0, y=1, relwidth=1, relheight=1)

C.pack()
top.mainloop

