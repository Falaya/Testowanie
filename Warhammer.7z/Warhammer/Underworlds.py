import pygame

pygame.init()

win = pygame.display.set_mode((1400, 700))
pygame.display.set_caption("Warhammer Underworlds")
bg = pygame.image.load("Boards.png")

class Steelheat(object):
    #Karty hero
    hero1_img = pygame.image.load("Hero_1.png")
    hero2_img = pygame.image.load("Hero_2.png")
    hero3_img = pygame.image.load("Hero_3.png")

    heroes = [[hero1_img, (100, 140), (0, 0)],
              [hero2_img, (100, 140), (0, 150)],
              [hero3_img, (100, 140), (0, 300)]]

    #Figurki
    #sciaga: [(kolor), (x, y, width, height)]
    figures = [[(255, 0, 0), [35, 55, 30, 30]],
               [(0, 255, 0), [35, 205, 30, 30]],
               [(0, 0, 255), [35, 355, 30, 30]]]


    def __init__(self):
        self.creator()

    def creator(self):
        for hero in Steelheat.heroes:
            hero_x = pygame.transform.scale(hero[0], hero[1])
            win.blit(hero_x, hero[2])
        for figure in Steelheat.figures:
            pygame.draw.rect(win, figure[0], figure[1])

x = 50
y = 50
width = 40
height = 60
vel = 5

x_2 = 100
y_2 = 100

isJump = False
jumpCount = 10

run = True

while run:
    pygame.time.delay(100)


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    if keys[pygame.K_ESCAPE]:
        run = False
    if keys[pygame.K_1]: #sciaga: [(kolor), (x, y, width, height)]
        if keys[pygame.K_LEFT] and x > vel:
            Steelheat.figures[0][1][0] -= vel
        if keys[pygame.K_RIGHT] and x < 500 - vel - width:
            Steelheat.figures[0][1][0] += vel
        if keys[pygame.K_UP] and y > vel:
            Steelheat.figures[0][1][1] -= vel
        if keys[pygame.K_DOWN] and y < 500 - height - vel:
            Steelheat.figures[0][1][1] += vel

    if keys[pygame.K_2]:
        if keys[pygame.K_LEFT] and x_2 > vel:
            Steelheat.figures[1][1][0] -= vel
        if keys[pygame.K_RIGHT] and x_2 < 500 - vel - width:
            Steelheat.figures[1][1][0] += vel
        if keys[pygame.K_UP] and y_2 > vel:
            Steelheat.figures[1][1][1] -= vel
        if keys[pygame.K_DOWN] and y_2 < 500 - height - vel:
            Steelheat.figures[1][1][1] += vel

    if keys[pygame.K_3]:
        if keys[pygame.K_LEFT] and x_2 > vel:
            Steelheat.figures[2][1][0] -= vel
        if keys[pygame.K_RIGHT] and x_2 < 500 - vel - width:
            Steelheat.figures[2][1][0] += vel
        if keys[pygame.K_UP] and y_2 > vel:
            Steelheat.figures[2][1][1] -= vel
        if keys[pygame.K_DOWN] and y_2 < 500 - height - vel:
            Steelheat.figures[2][1][1] += vel

    if keys[pygame.K_TAB]:
        if x < 250 and y < 140:
            win.blit(Steelheat.hero1_img, (0, 0))
            pygame.display.update()
        elif x < 250 and y > 150 and y < 290:
            win.blit(Steelheat.hero2_img, (0, 0))
            pygame.display.update()
        elif x < 250 and y > 300 and y < 440:
            win.blit(Steelheat.hero3_img, (0, 0))
            pygame.display.update()
    else:
        win.fill((0, 0, 0))
        win.blit(bg, (300,0))
        Steelheat()
        pygame.draw.rect(win, (255, 0, 0), (x, y, width, height))
        pygame.display.update()

pygame.quit()